#Paramêtros: ./plot <resultado1> [resultado2 ... resultado5]

#!/usr/bin/python3

import sys
import plotly as py
import plotly.graph_objs as go

def main():
	print(len(sys.argv))
	if len(sys.argv) == 2:
		trace1(sys.argv[1])
	elif len(sys.argv) == 3:
		trace2(sys.argv[1], sys.argv[2])
	elif len(sys.argv) == 4:
		trace3(sys.argv[1], sys.argv[2], sys.argv[3])
	elif len(sys.argv) == 6:
		trace5(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
	else:
		print("ERRO ENTRADA DE PARAMETROS")

def trace1(trace0=None):
	if trace0 is not None:
		arq = open(trace0,"r")

		entry0 = []
		executionTime0 = []
		for line in arq:
			entry0.append(line.split()[1])
			executionTime0.append(line.split()[5])	

		data0 = go.Scatter(
 			x=entry0,
 			y=executionTime0,
 			name=trace0[:-11]
	 	)
	data = [data0]
	plot(data)

def trace2(trace0=None, trace1=None):
	if trace0 is not None:
		arq = open(trace0,"r")

		entry0 = []
		executionTime0 = []
		for line in arq:
			entry0.append(line.split()[1])
			executionTime0.append(line.split()[5])	

		data0 = go.Scatter(
 			x=entry0,
 			y=executionTime0,
 			name=trace0[:-11]
	 	)

	if trace1 is not None:
		arq = open(trace1,"r")

		entry1 = []
		executionTime1 = []
		for line in arq:
			entry1.append(line.split()[1])
			executionTime1.append(line.split()[5])

		data1 = go.Scatter(
 			x=entry1,
 			y=executionTime1,
 			name=trace1[:-11]
	 	)
		
	data = [data0, data1]
	plot(data)
	
def trace3(trace0=None, trace1=None, trace2=None):
	if trace0 is not None:
		arq = open(trace0,"r")

		entry0 = []
		executionTime0 = []
		for line in arq:
			entry0.append(line.split()[1])
			executionTime0.append(line.split()[5])	

		data0 = go.Scatter(
 			x=entry0,
 			y=executionTime0,
 			name=trace0[:-11]
	 	)

	if trace1 is not None:
		arq = open(trace1,"r")

		entry1 = []
		executionTime1 = []
		for line in arq:
			entry1.append(line.split()[1])
			executionTime1.append(line.split()[5])

		data1 = go.Scatter(
 			x=entry1,
 			y=executionTime1,
 			name=trace1[:-11]
	 	)
	
	if trace2 is not None:
		arq = open(trace2,"r")

		entry2 = []
		executionTime2 = []
		for line in arq:
			entry2.append(line.split()[1])
			executionTime2.append(line.split()[5])	

		data2 = go.Scatter(
 			x=entry2,
 			y=executionTime2,
 			name=trace2[:-11]
	 	)

	data = [data0, data1, data2]
	plot(data)

def trace5(trace0=None, trace1=None, trace2=None, trace3=None , trace4=None):
	if trace0 is not None:
		arq = open(trace0,"r")

		entry0 = []
		executionTime0 = []
		for line in arq:
			entry0.append(line.split()[1])
			executionTime0.append(line.split()[5])	
		
		data0 = go.Scatter(
 			x=entry0,
 			y=executionTime0,
 			name=trace0[:-11]
	 	)

	if trace1 is not None:
		arq = open(trace1,"r")

		entry1 = []
		executionTime1 = []
		for line in arq:
			entry1.append(line.split()[1])
			executionTime1.append(line.split()[5])
		
		data1 = go.Scatter(
 			x=entry1,
 			y=executionTime1,
 			name=trace1[:-11]
	 	)
	
	if trace2 is not None:
		arq = open(trace2,"r")

		entry2 = []
		executionTime2 = []
		for line in arq:
			entry2.append(line.split()[1])
			executionTime2.append(line.split()[5])	
		
		data2 = go.Scatter(
 			x=entry2,
 			y=executionTime2,
 			name=trace2[:-11]
	 	)

	if trace3 is not None:
		arq = open(trace3,"r")

		entry3 = []
		executionTime3 = []
		for line in arq:
			entry3.append(line.split()[1])
			executionTime3.append(line.split()[5])	
		
		data3 = go.Scatter(
 			x=entry3,
 			y=executionTime3,
 			name=trace3[:-11]
	 	)

	if trace4 is not None:
		arq = open(trace4,"r")

		entry4 = []
		executionTime4 = []
		for line in arq:
			entry4.append(line.split()[1])
			executionTime4.append(line.split()[5])		
		
		data4 = go.Scatter(
 			x=entry4,
 			y=executionTime4,
 			name=trace4[:-11]
	 	)

	data = [data0, data1, data2, data3, data4]
	plot(data)


def plot(data=None):
	layout = go.Layout(
		title='Comparativo algoritmos de ordenação',
		font=dict(family='Courier New, monospace', size=14, color='#7f7f7f'),
    		xaxis=dict(
        		title='Entrada(n)',
        		titlefont=dict(
            			family='Courier New, monospace',
            			size=12,
            			color='#7f7f7f'
        		)
    		),
    		yaxis=dict(
        		title='Tempo de execução(s)',
        		titlefont=dict(
         			family='Courier New, monospace',
            			size=12,
            			color='#7f7f7f'
        		)
    		)
	)

	fig = go.Figure(data=data, layout=layout)
	py.offline.plot(fig)

if __name__ == '__main__':
	main()
